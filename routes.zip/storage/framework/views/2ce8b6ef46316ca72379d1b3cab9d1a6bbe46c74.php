<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Flights')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

<?php $__env->startSection('content'); ?>



    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p></p>
            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('flight_create')); ?>" > Create </a>
        <table style="width: 100%">
            <tr>
                <th>Airline Code</th>
                <th>Flight Number</th>
                <th>Departure Airport</th>
                <th>Departure Time</th>
                <th>Arrival Airport</th>
                <th>Arrival Time</th>
                <th>Price</th>
                <th>Actions</th>
            </tr>
            <?php $__currentLoopData = $flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="text-align: center">
                    <td><?php echo $flight->airline;; ?></td>
                    <td><?php echo $flight->number;; ?></td>
                    <td><?php echo $flight->departure_airport;; ?></td>
                    <td><?php echo $flight->departure_time;; ?></td>
                    <td><?php echo $flight->arrival_airport;; ?></td>
                    <td><?php echo $flight->arrival_time;; ?></td>
                    <td><?php echo $flight->price;; ?></td>
                    <td>
                        <form action="<?php echo e(route('flight_delete',['id'=>$flight])); ?>" method="POST">


                            <a href="<?php echo e(route('flight_edit', ['id'=> $flight])); ?>">
                                <i class="fas fa-edit  fa-lg">EDIT</i>
                            </a>

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit" title="delete" style="border: none; background-color:transparent;">
                                <i class="fas fa-trash fa-lg text-danger"> Delete</i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <?php echo $flights->links(); ?>

        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/admin/flight.blade.php ENDPATH**/ ?>